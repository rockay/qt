﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace rcsdk_test
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
       
        //CreateChannel
        MessageListenerEventHandler msg_callback = new MessageListenerEventHandler(set_message_listener_callback_delegate.set_message_listener_call_back);
        ExceptionListenerEventHandler exception_callback = new ExceptionListenerEventHandler(exception_listener_callback_delegate.exception_listener_call_back);
        PublishAckListenerEventHandler send_call_back = new PublishAckListenerEventHandler(send_message_callback_delegate.send_message_call_back);
        /*
        线上测试账号：
         xl1:
         token: 7V47hux2sxdmohiybibkaUmcbyeYIrXSDa0nFvL2mH/ktTByrE9l+qMFJwoIZV7RkVZcdq+5OgTBsvVJws7aQQ==
         userid:77552

         xl2:
         token: M4fzpKAIT4lmohiybibkaUmcbyeYIrXSDa0nFvL2mH/ktTByrE9l+vpI9c07gsj5kVZcdq+5OgQOvMx9qBHkvA==
          userid:77553

         xl3:
         token: ctHXYZPMZ/DkoiBwst9rRM2yq+hfEluLjZ78E1qo4hGEwEdzMQZ6WajBrPU6hjQcHM0YEh0kilaflH+9jL+4eQ==
         userid:77554

         泛微ky：
         token： bOI/lGjKES9JNKBqOueR1kmcbyeYIrXSDa0nFvL2mH/xbYhB5dHSTJ1YUVahaQoAcTZzNsYUV47WfsYXpExsWw== 
         */
        private void button1_Click(object sender, EventArgs e)
        {
            //"M4fzpKAIT4lmohiybibkaUmcbyeYIrXSDa0nFvL2mH/ktTByrE9l+vpI9c07gsj5kVZcdq+5OgQOvMx9qBHkvA==";
            string szToken = "7V47hux2sxdmohiybibkaUmcbyeYIrXSDa0nFvL2mH/ktTByrE9l+qMFJwoIZV7RkVZcdq+5OgTBsvVJws7aQQ==";
            ConnectAckListenerEventHandler connect_ack_call_back = new ConnectAckListenerEventHandler(connect_ack_callback_delegate.connect_call_back);
            if (connect_ack_call_back == null)
            {
                MessageBox.Show("hello");
            }
             string path = System.Environment.CurrentDirectory;
            //string path = "C:\\workspace\\中 文路径";
            rcsdk.InitClient("z3v5yqkbv8v30", "dd你好宁", "deviceid", path, path);
            rcsdk.SetDeviceInfo("Apple", "mac pro", "win10", "WIFI", "");
            //文本消息
            rcsdk.RegisterMessageType("RC:TxtMsg", 3);
            //图片消息
            rcsdk.RegisterMessageType("RC:ImgMsg", 3);
            //图文消息
            rcsdk.RegisterMessageType("RC:VcMsg", 3);
            //位置消息
            rcsdk.RegisterMessageType("RC:LBSMsg", 3);
            //添加联系人消息
            rcsdk.RegisterMessageType("RC:ContactNtf", 3);
            //提示条（小灰条）通知消息
            rcsdk.RegisterMessageType("RC:InfoNtf", 3);
            //资料通知消息
            rcsdk.RegisterMessageType("RC:ProfileNtf", 3);
            //通用命令通知消息
            rcsdk.RegisterMessageType("RC:CmdNtf", 3);
            //设置消息监听
            rcsdk.SetMessageListener(msg_callback);
            //设置网络异常监听
            rcsdk.SetExceptionListener(exception_callback);
            rcsdk.Connect(szToken, connect_ack_call_back);
        }
        //DestroyChannel
        private void button2_Click(object sender, EventArgs e)
        {
            rcsdk.Disconnect(2);
        }

        //InviteToDiscussion
        private void button21_Click(object sender, EventArgs e)
        {
            PublishAckListenerEventHandler invite_callback = new PublishAckListenerEventHandler(invite_member_todiscussion_callback_delegate.invite_to_discussion_call_back);
            RcTargetEntry[] userIds = new RcTargetEntry[1];
            userIds[0].targetName = "22";
            userIds[0].targetId = "33";
            rcsdk.AddMemberToDiscussion("discussionid", userIds, 3, invite_callback);
        }

        //TestNetWork
        private void button3_Click(object sender, EventArgs e)
        {

        }

        //SaveMessage
        private void button4_Click(object sender, EventArgs e)
        {
            string szContent = "我家大融dskfjsaldjfksajflsajflasjfkldsa;jf;asmfk云大融云";
            long messageId = rcsdk.SaveMessage("77552", 3, "RC:TxtMsg", "77553", szContent, "", "",false,0);
        }

        //DownLoadImage
        private void button39_Click(object sender, EventArgs e)
        {
            ImageListenerEventHandler image_call_back = new ImageListenerEventHandler(down_file_with_url_callback_delegate.down_file_with_url_call_back);
            ImageListenerEventHandler image_process_call_back = new ImageListenerEventHandler(down_file_with_url_callback_delegate.down_file_with_url_process_call_back);
            string url_str = "http://rongcloud-image.ronghub.com/image_jpeg__RC-0115-10-16_41_1447640600?e=2147483647&token=CddrKW5AbOMQaDRwc3ReDNvo3-sL_SO1fSUBKV3H:WAC8m54MzC8-qInxW6Xw3nIE46g=";
            rcsdk.DownLoadFile("77552", 1, 1,url_str, image_call_back, image_process_call_back);
        }

        //SendImageMsg
        public static void send_file_with_url_process_call_back(string json_str)
        {
            //在这里添加通知UI层代码
            JObject jobj = JObject.Parse(json_str);
        }
        public static void send_file_with_url_call_back(string json_str)
        {
            //在这里添加通知UI层代码
            JObject jobj = JObject.Parse(json_str);
            string result = (string)jobj["result"];
            if (result == "failed")
            {
                return;
            }
            string url = (string)jobj["url"];

            //先生成缩略图
            string image_path = "C:\\workspace\\winsdk-vs-2015\\protocol-stack\\win_rcsdk\\images\\";
            string src_img_path = image_path + "33.jpg";
            string thum_img_path = image_path + "33_th.jpg";
            image_helper.MakeThumbnail(src_img_path, thum_img_path, 15, 15, "HW");
            //进行base64编码
            Image thum_img = Image.FromFile(thum_img_path);
            byte[] thum_img_bytes = image_helper.ImageToBytes(thum_img);
            string thum_img_base64 = Convert.ToBase64String(thum_img_bytes);
            JObject msg_jobj = new JObject();
            msg_jobj["content"] = thum_img_base64;
            msg_jobj["imageUri"] = url;
            msg_jobj["extra"] = "";
            int messageId = rcsdk.SaveMessage("77552", 1, "RC:ImgMsg", "77553", msg_jobj.ToString(), "", "",false,0);
            PublishAckListenerEventHandler send_img_msg_call_back = new PublishAckListenerEventHandler(send_message_callback_delegate.send_message_call_back);
            rcsdk.sendMessage("77553", 1, 2, "RC:ImgMsg", msg_jobj.ToString(), "", "", messageId, send_img_msg_call_back);
        }
        private void button5_Click(object sender, EventArgs e)
        {
            //原图上传
            string image_path = "C:\\workspace\\winsdk-vs-2015\\protocol-stack\\win_rcsdk\\images\\";
            string src_img_path = image_path + "33.jpg";
            ImageListenerEventHandler image_call_back = new ImageListenerEventHandler(send_file_with_url_call_back);
            ImageListenerEventHandler image_process_call_back = new ImageListenerEventHandler(send_file_with_url_process_call_back);
            Image src_img = Image.FromFile(src_img_path);
            byte[] src_img_bytes = image_helper.ImageToBytes(src_img);
            rcsdk.UpLoadFile("77553", 1, 1, src_img_bytes, src_img_bytes.Count(), "123456",image_call_back, image_process_call_back);
        }

        /// <summary>
        /// 将普通文本转换成Base64编码的文本
        /// </summary>
        /// <param name="value">普通文本</param>
        /// <returns></returns>
        public string StringToBase64String(String value)
        {
            byte[] binBuffer = (new UTF8Encoding()).GetBytes(value);
            int base64ArraySize = (int)Math.Ceiling(binBuffer.Length / 3d) * 4;
            char[] charBuffer = new char[base64ArraySize];
            Convert.ToBase64CharArray(binBuffer, 0, binBuffer.Length, charBuffer, 0);
            string s = new string(charBuffer);
            return s;
        }

        //SendMessage
        private void button6_Click(object sender, EventArgs e)
        {
            //"😳😎😜😀😲 表情发送
            JObject jobj = new JObject();
            jobj["content"] = "haha😜\r\n表情发送😳😎😜😀😲";//"表情发送😳😎😜😀😲";
           
            //单聊文本消息
            int messageId = rcsdk.SaveMessage("77553", 1, "RC:TxtMsg", "77553", jobj.ToString(), "", "",false,0);
            rcsdk.sendMessage("77553", 1, 2, "RC:TxtMsg", jobj.ToString(), "", "", messageId, send_call_back);

            //讨论组消息 xl_123 id:d2995e25-e7e2-4cbe-94d1-ad106276b93e
            //int messageId = rcsdk.SaveMessage("d2995e25-e7e2-4cbe-94d1-ad106276b93e", 3, "RC:TxtMsg", "77552", jobj.ToString(), "", "");
            //rcsdk.send_message("d2995e25-e7e2-4cbe-94d1-ad106276b93e", 2, 3, "RC:TxtMsg", jobj.ToString(), "", "", messageId, send_call_back);
        }

        //GetConversation
        private void button11_Click(object sender, EventArgs e)
        {
            ConversationInfoEventHandler callback = new ConversationInfoEventHandler(get_con_ex_callback_delegate.get_con_ex_call_back);
            rcsdk.GetConversation("77553", 1, callback);
        }

        //GetConversationList
        private void button27_Click(object sender, EventArgs e)
        {
            int[] conversationDict = new int[3];
            conversationDict[0] = 1;
            conversationDict[1] = 2;
            conversationDict[2] = 3;
            ConversationInfoEventHandler callback = new ConversationInfoEventHandler(get_con_listex_callback_delegate.get_con_listex_call_back);
            rcsdk.GetConversationList(conversationDict, 3, callback);
        }

        //GetHistoryMessages
        private void button10_Click(object sender, EventArgs e)
        {
            //RC:TxtMsg
            MessageInfoEventHandler get_paged_callback = new MessageInfoEventHandler(get_paged_messageex_callback_delegate.get_paged_messagex_call_back);
            rcsdk.GetHistoryMessages("77553", 1, "", -1,100, get_paged_callback);
        }

        //RemoveConversations
        private void button19_Click(object sender, EventArgs e)
        {
            rcsdk.RemoveConversation("77553", 1);
        }

        //ClearConversations
        private void button12_Click(object sender, EventArgs e)
        {
            int[] clearids = new int[3];
            clearids[0] = 1;
            clearids[1] = 2;
            clearids[2] = 3;
            rcsdk.ClearConversations(clearids, 3);
        }

        //ClearUnread
        private void button9_Click(object sender, EventArgs e)
        {
            rcsdk.ClearMessagesUnreadStatus("40", 1);
        }

        //GetTotalUnreadCount
        private void button13_Click(object sender, EventArgs e)
        {
            int[] entry = new int[2];
            entry[0] = 9;
            entry[1] = 2;
            rcsdk.GetConversationUnreadCount(entry, 2);
        }

        //SetIsTop
        private void button8_Click(object sender, EventArgs e)
        {
            rcsdk.SetConversationToTop("40", 1, true);
        }

        //DeleteMessage
        private void button15_Click(object sender, EventArgs e)
        {
           int[] entry = new int[3];
            entry[0] = 3;
            entry[1] = 4;
            entry[2] = 5;
            rcsdk.DeleteMessage(new int[] {2}, 1);
        }

        //GetUserInfo
        private void button7_Click(object sender, EventArgs e)
        {
            UserInfoListenerEventHandler user_info_callback = new UserInfoListenerEventHandler(get_user_info_callback_delegate.get_userinfo_call_back);
            rcsdk.GetUserInfo("43", user_info_callback);
        }

        //CreateDiscussion
        private void button16_Click(object sender, EventArgs e)
        {
            CreateDiscussionListenerEventHandler create_discussion_callback = new CreateDiscussionListenerEventHandler(create_invite_discussion_callback_delegate.create_invite_discussion_call_back);
            RcTargetEntry[] userIds = new RcTargetEntry[2];
            userIds[0].targetId = "77553";
            userIds[0].targetName = "xl2";
            userIds[1].targetId = "77554";
            userIds[1].targetName = "xl3";
            rcsdk.CreateDiscussion("xl_123", userIds, 2, create_discussion_callback);
        }

        //ClearMessage
        private void button14_Click(object sender, EventArgs e)
        {
            rcsdk.ClearMessages("6", 1);
        }

        //QuitDiscussion
        private void button17_Click(object sender, EventArgs e)
        {
            string g_discussionId = "22";
            PublishAckListenerEventHandler quit_callback = new PublishAckListenerEventHandler(quit_discussion_callback_delegate.quit_discussion_call_back);
            rcsdk.QuitDiscussion(g_discussionId, quit_callback);
        }

        //GetDiscussionInfo
        private void button18_Click(object sender, EventArgs e)
        {
            //讨论组xl_123 id:d2995e25-e7e2-4cbe-94d1-ad106276b93e
            DiscussionInfoListenerEventHandler dis_info_callback = new DiscussionInfoListenerEventHandler(discussion_info_callback_delegate.discussion_info_call_back);
            rcsdk.GetDiscussionInfo("d2995e25-e7e2-4cbe-94d1-ad106276b93e", 2, dis_info_callback);
        }

        //RemoveMemberFromDiscussion
        private void button22_Click(object sender, EventArgs e)
        {
            PublishAckListenerEventHandler remove_callback = new PublishAckListenerEventHandler(remove_member_from_discussion_callback_delegate.remove_member_from_discussion_call_back);
            rcsdk.RemoveMemberFromDiscussion("4", "40", remove_callback);
        }

        private void button23_Click(object sender, EventArgs e)
        {

        }

        //JoinChatRoom
        private void button20_Click(object sender, EventArgs e)
        {
            PublishAckListenerEventHandler join_callback = new PublishAckListenerEventHandler(join_chatroom_callback_delegate.join_chatroom_call_back);
            rcsdk.JoinChatRoom("110119", 4, 0, join_callback);
            //rcsdk.JoinExistingChatRoom("110119", 4, 1, join_callback);
        }

        //QuitChatRoom
        private void button24_Click(object sender, EventArgs e)
        {
            PublishAckListenerEventHandler quit_callback = new PublishAckListenerEventHandler(quit_chatroom_callback_delegate.quit_chatroom_call_back);
            rcsdk.QuitChatRoom("23087", 4, quit_callback);
        }

        //GetBlacklist
        private void button47_Click(object sender, EventArgs e)
        {
            BlacklistInfoListenerEventHandler black_list_callback = new BlacklistInfoListenerEventHandler(black_list_callback_delegate.black_list_call_back);
            rcsdk.GetBlacklist(black_list_callback);
        }

        //AddToBlacklist
        private void button44_Click(object sender, EventArgs e)
        {
            PublishAckListenerEventHandler add_callback = new PublishAckListenerEventHandler(add_to_black_callback_delegate.add_to_black_call_back);
            rcsdk.AddToBlacklist("6", add_callback);
        }

        //RemoveFromBlacklist
        private void button43_Click(object sender, EventArgs e)
        {
            PublishAckListenerEventHandler remove_callback = new PublishAckListenerEventHandler(remove_from_black_callback_delegate.remove_from_black_call_back);
            rcsdk.RemoveFromBlacklist("ctest", remove_callback);
        }

        //SetBlockPush
        private void button41_Click(object sender, EventArgs e)
        {
            BizAckListenerEventHandler set_block_push_callback = new BizAckListenerEventHandler(set_block_push_callback_delegate.set_block_push_call_back);
            rcsdk.SetConversationNotificationStatus("22", 2, true, set_block_push_callback);
        }

        //RenameDiscussion
        private void button45_Click(object sender, EventArgs e)
        {
            PublishAckListenerEventHandler rename_discussion_callback = new PublishAckListenerEventHandler(rename_discussion_callback_delegate.rename_discussion_call_back);
            rcsdk.RenameDiscussion("dd", "abcde", rename_discussion_callback);
        }

        //SetInviteStatus
        private void button42_Click(object sender, EventArgs e)
        {
            PublishAckListenerEventHandler invite_callback = new PublishAckListenerEventHandler(set_invite_status_callback_delegate.set_invite_status_call_back);
            rcsdk.SetDiscussionInviteStatus("3513cf3a-3cea-45f4-94af-292d5a015411", 1, invite_callback);
        }

        //SyncGroups
        private void button3_Click_1(object sender, EventArgs e)
        {
            RcTargetEntry[] groupids = new RcTargetEntry[3];
            groupids[0].targetId = "123";
            groupids[0].targetName = "grp1";
            groupids[1].targetId = "223";
            groupids[1].targetName = "grp2";
            groupids[2].targetId = "323";
            groupids[2].targetName = "grp3";
            PublishAckListenerEventHandler group_callback = new PublishAckListenerEventHandler(sync_groups_callback_delegate.sync_groups_call_back);
            rcsdk.SyncGroups(groupids, 3, group_callback);
        }

        //JoinGroup
        private void button23_Click_1(object sender, EventArgs e)
        {
            RcTargetEntry[] groupids = new RcTargetEntry[3];
            groupids[0].targetId = "123";
            groupids[0].targetName = "grp1";
            groupids[1].targetId = "223";
            groupids[1].targetName = "grp2";
            groupids[2].targetId = "323";
            groupids[2].targetName = "grp3";
            PublishAckListenerEventHandler group_callback = new PublishAckListenerEventHandler(sync_groups_callback_delegate.sync_groups_call_back);
            rcsdk.JoinGroup(groupids, 3, group_callback);
        }

        //QuitGroup
        private void button25_Click(object sender, EventArgs e)
        {
            RcTargetEntry[] groupids = new RcTargetEntry[3];
            groupids[0].targetId = "123";
            groupids[0].targetName = "grp1";
            groupids[1].targetId = "223";
            groupids[1].targetName = "grp2";
            groupids[2].targetId = "323";
            groupids[2].targetName = "grp3";
            PublishAckListenerEventHandler group_callback = new PublishAckListenerEventHandler(sync_groups_callback_delegate.sync_groups_call_back);
            rcsdk.QuitGroup(groupids, 3, group_callback);
        }

        //EncodeWavToAmr
        private void button26_Click(object sender, EventArgs e)
        {
            rcsdk.EncodeWavToAmr("1.wav", "2.amr", 1, 16);
        }

        //DecodeAmrToWav
        private void button46_Click(object sender, EventArgs e)
        {
            rcsdk.DecodeAmrToWav("2.amr","3.wav");
        }

        private void button28_Click(object sender, EventArgs e)
        {
            rcsdk.RecordToWav(1,8000,16);
        }

        private void button29_Click(object sender, EventArgs e)
        {
            string wav_path = System.Environment.CurrentDirectory + "\\liuning.wav";
            rcsdk.SaveToWav(wav_path);
        }
    }
}
