#include "widget.h"
#include <QApplication>
#include "qrwidget.h"
#include <QQuickView>
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
//    Widget w;
//    w.show();
//    QRWidget myQrencode;
//    myQrencode.setQRData("落霞与孤鹜齐飞\n秋水共长天一色");
//    myQrencode.resize(400,400);
//    myQrencode.show();
    //myQrencode.move((this->width()/2-100)/2,(this->height()/2-100)/2);


    QQuickView *view = new QQuickView;
    view->setSource(QUrl("../../../ChatView.qml"));
    view->show();
    return a.exec();
}
//#include<iostream>
//using namespace std;
//#define null NULL
//struct node
//{
//    int data;
//    node* next;
//};
//int main()
//{
//    node* head=new node;
//    head->data=0;
//    head->next=null;
//    node* p=head;
//    for(int i=1;i<10;i++)
//    {
//        node* tmp=new node;
//        tmp->data=i;
//        tmp->next=null;
//        head->next=tmp;
//        head=head->next;
//    }
//    std::cout<<"p->data "<<p->next<<std::endl;
//    while(p!=p->next || p!=null)
//    {
//        std::cout<<"fuck"<<p<<" "<<p->next<<std::endl;
//        p->next->next=p->next->next->next;
//        p=p->next->next;
//    }
//    return 0;
//}
//#include<stdio.h>
//#include<stdlib.h>

//typedef struct data
//{
//    //定义一个结构体“data”
//    int num; //用于存放人的序号
//    int val; //用于存放密码
//}typedata;

//typedef struct node
//{
//    //定义一个结构体（结点），其中包含一个数据域和一个指针域
//    typedata data; //结构体的嵌套
//    struct node *next;
//}listnode;

//typedef listnode *linklist;
//linklist head;

//int main()// 进入主函数
//{
//    int n,i,b,m,j;
//    linklist head=(listnode *)malloc(sizeof(listnode)); //申请一个空间（头结点 head）
//    listnode *p,*q; //定义两个可以指向结点的指针
//    printf("输入总人数：");
//    scanf("%d",&n);
//    q=head; //用指针q指向头结点

//    for(j=1;j<=n;j++) //本次循环主要是将每一个人的数据（包括序号、密码）存入循环链表中
//    {
//        printf("请输入第%d号同学的密码:\n",j);
//        scanf("%d",&b);
//        printf("\n");
//        q->next=(listnode *)malloc(sizeof(listnode));
//        //将头结点的next域指向刚生成的一个结点
//        q=q->next;
//        q->data.val=b; //输入密码
//        q->data.num=j; //输入序号
//        q->next=head->next;
//    }

//    //将尾结点的next域指向第一个结点，构成循环链表
//    printf("请任意输入一个数m：");
//    scanf("%d",&m);

//    if(m<=0) printf("输入错误");

//    do
//    {
//        i=1;

//        while(i!=m)
//        {
//            //将q指针指向所要输出的结点的前一结点
//            q=q->next;
//            i++;
//        }
//        p=q->next; //p指向输出结点
//        q->next=p->next; //将输出结点的前结点的next域指向输出结点的后结点
//        printf("num:%d\tval:%d\n",p->data.num,p->data.val); //输出
//        m=p->data.val; //取得输出结点的密码
//        free(p);
//    }

//    while(q->next!=q); //只剩最后一个结点时结束

//    printf("num:%d\tval:%d\n",q->data.num,q->data.val); //输出最后一个结点

//    free(q); //释放最后一个结点
//    free(head); //释放头结点

//    printf("约瑟夫环结束，欢迎下次光临~·~\n");
//    return 0;
//}
